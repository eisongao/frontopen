<?php
	 $logo = '1';
	 $layout = '0';
	 $style = '0';
	 $welcome = '2';				 
	 $social = '1';				 
         $fenlei = '1';
         $silder = '2';				 
	 $fo2_ad = '';
         $fo2_ad_1 = '1';
	 $fo2_ad_2 = '';
	 $fo2_ad_3 = '';
         $fo2_ad_4 = '';
	 $fo3_ad = '<a href="http://komass.com/" target="_blank" title=""><img src="http://komass.com/content/templates/frontopen3/img/ad-728-902.png" alt="" class="img-responsive"></a>';
	 $fo3_ad1 = '<a href="#1" target="_blank" title=""><img src="http://demo.betterstudio.com/better-mag/wp-content/uploads/sites/2/2014/08/ad-clock-728x90.jpg" alt="" class="img-responsive">
</a>';
         $fo3_ad2 = '<a href="#1" target="_blank" title=""><img src="http://demo.betterstudio.com/better-mag/wp-content/uploads/sites/2/2014/08/ad-clock-728x90.jpg" alt="" class="img-responsive">
</a>';
	 $fo3_ad3 = '<a href="#1" target="_blank" title=""><img src="http://demo.betterstudio.com/better-mag/wp-content/uploads/sites/2/2014/08/ad-clock-728x90.jpg" alt="" class="img-responsive">
</a>';
	 $fo3_ad4 = '';
	 $compress_html = '2';
	 $tab_ad = '<article class="post-158 type-post status-publish format-standard has-post-thumbnail  block-modern main-term-12">
<a class="post-thumbnail image-link" href="#"><img width="360" height="340" src="http://komass.com/content/templates/frontopen3/img/tabad.png" class="img-responsive wp-post-image">
</a>
</article>';
	 $zoom = '1';
         $thm = '1';
         $top = '1';
	 $topbar = '1';
         $sortout  = '2';				 
         $sildurl1 = '#';
         $sildurl2 = '#';
         $sildurl3 = '#';
	 $sildurl4 = '#';
         $sildurl5 = '#';
         $sildcustom1 = '测试幻灯片效果之一';
         $sildcustom2 = '测试幻灯片效果';
         $sildcustom3 = '测试幻灯片效果';
         $sildcustom4 = '测试幻灯片效果';
         $sildcustom5 = '测试幻灯片效果';
         $sildimg1 = 'http://komass.com/content/templates/frontopen3/img/silder/5.jpg';
         $sildimg2 = 'http://komass.com/content/templates/frontopen3/img/silder/4.jpg';
         $sildimg3 = 'http://komass.com/content/templates/frontopen3/img/silder/3.jpg';
         $sildimg4 = 'http://komass.com/content/templates/frontopen3/img/silder/2.jpg';
         $sildimg5 = 'http://komass.com/content/templates/frontopen3/img/silder/1.jpg';
	 $sort_id =array(1,2,3,);
         $forumane1 = '网站建设';
         $forumane2 = '休闲时刻';
         $forumane3 = '无奈学习';				 
         $forumane4 = '网络资讯';				 
         $forumane5 = '站内消息';				 
         $forumida =array(1,5,);
         $forumidb = array(8,9,10,15,);
         $forumidc = array(12,7,);					 
         $forumidd = array(3,4,16,17,);					 
         $forumide = array(2,14,);					 
	 $bbsout = '2';
	 $video = '2';
	 $sidebar = '1';
	 $cusname = '公司简介';
	 $cusnames = '产品展示';
	 $contact = 'Flyer';
	 $phone = '1234546677';
	 $iphone = '1233456656';
	 $cmail = 'dddd@qq.com';
	 $customy = '';
	 $customq = '';
	 $customf = '';
	 $customt = '';
	 $address = '2222 XXXXX china 11111';
	 $about = '该公司成立于2016年，位于某某区，有良好的团队，主要项目有很多！~~Emlog,wordpress,zblog,magento,opencat,diszuc!~等等该公司成立于2016年，位于某某区，有良好的团队，主要项目有很多！~~Emlog,wordpress,zblog,magento,opencat,diszuc!~等等该公司成立于2016年，位于某某区，有良好的团队，主要项目有很多！~~Emlog,wordpress,zblog,magento,opencat,diszuc!~等等该公司成立于2016年，位于某某区，有良好的团队，主要项目有很多！~~Emlog,wordpress,zblog,magento,opencat,diszuc!~等等该公司成立于2016年，位于某某区，有良好的团队，主要项目有很多！~~Emlog,wordpress,zblog,magento,opencat,diszuc!~等等该公司成立于2016年，位于某某区，有良好的团队，主要项目有很多！~~Emlog,wordpress,zblog,magento,opencat,diszuc!~等等';
	 $cms_id =array(1,3,2,);
	 $video_id =array(1,2,3,);
	 $cmsimg ='2';
	 $tabtools ='1';
	 $caiji='2';	 
         $socialweibo='http://qq.com/';
	 $socialsina ='http://sina.com/';
	 $qq ='123456';
	 $xavatar='2';
	 $waterfall='2';
	 $useragent='1';
?>