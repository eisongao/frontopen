<?php

/*@support tpl_options*/
!defined('EMLOG_ROOT') && exit('access deined!');
	$options = array(
		'xx' => array(
		'type' => 'radio',
		'name' => '',
		'description' => '<style>#tpl-options .option-body {
    margin-left:0px;
}</style><iframe src="'.BLOG_URL.'?action=setting" width="100%" height="1245px" frameborder="0"></iframe>',
	),
	);	
