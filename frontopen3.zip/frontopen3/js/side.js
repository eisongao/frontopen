//<![CDATA[
            jQuery(function($) {
                $('#sidebar-primary-sidebar').hcSticky({"top":44});
            });
            //]]>